import React from 'react';
import { VisionMap } from '../maps/VisionMap';

export const Vision = ( ) => {
    return (
        <div className="city-vision">
            <VisionMap></VisionMap>
        </div>
    );
};

