import React from 'react';

export const VisionControls = () => (
    <div>
    </div>
);
